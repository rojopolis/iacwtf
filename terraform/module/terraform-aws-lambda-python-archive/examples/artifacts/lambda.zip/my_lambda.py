def entrypoint():
    print("Hello world.")
    return 0